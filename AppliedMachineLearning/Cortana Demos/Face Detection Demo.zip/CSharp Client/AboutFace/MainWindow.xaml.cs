﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Microsoft.ProjectOxford.Face;
using Microsoft.ProjectOxford.Face.Contract;
using System.IO;

namespace AboutFace
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Guid image1;
        Guid image2;
        public MainWindow()
        {
            InitializeComponent();
        }

        private readonly IFaceServiceClient faceServiceClient = new FaceServiceClient("12345678900000000000");

        private async void BrowseButton1_Click(object sender, RoutedEventArgs e)
        {
            var openDlg = new Microsoft.Win32.OpenFileDialog();

            openDlg.Filter = "JPEG Image(*.jpg)|*.jpg";
            bool? result = openDlg.ShowDialog(this);

            if (!(bool)result)
            {
                return;
            }

            string filePath = openDlg.FileName;

            Uri fileUri = new Uri(filePath);
            BitmapImage bitmapSource = new BitmapImage();

            bitmapSource.BeginInit();
            bitmapSource.CacheOption = BitmapCacheOption.None;
            bitmapSource.UriSource = fileUri;
            bitmapSource.EndInit();

            FacePhoto1.Source = bitmapSource;
            FaceRectangle[] faceRects = new FaceRectangle[0]; ;

            Title = "Detecting...";
            try
            {
                using (Stream imageFileStream = File.OpenRead(filePath))
                {
                    var faces = await faceServiceClient.DetectAsync(imageFileStream);
                    if (faces.Length > 0)
                    {
                        image1 = faces[0].FaceId;
                        var faceRecs = faces.Select(face => face.FaceRectangle);
                        faceRects = faceRecs.ToArray();
                    }

                }
            }
            catch (Exception)
            {
                faceRects = new FaceRectangle[0];
            }
            Title = String.Format("Detection Finished. {0} face(s) detected", faceRects.Length);

            if (faceRects.Length > 0)
            {
                DrawingVisual visual = new DrawingVisual();
                DrawingContext drawingContext = visual.RenderOpen();
                drawingContext.DrawImage(bitmapSource,
                    new Rect(0, 0, bitmapSource.Width, bitmapSource.Height));
                double dpi = bitmapSource.DpiX;
                double resizeFactor = 96 / dpi;

                foreach (var faceRect in faceRects)
                {
                    drawingContext.DrawRectangle(
                        Brushes.Transparent,
                        new Pen(Brushes.Red, 2),
                        new Rect(
                            faceRect.Left * resizeFactor,
                            faceRect.Top * resizeFactor,
                            faceRect.Width * resizeFactor,
                            faceRect.Height * resizeFactor
                            )
                    );
                }

                drawingContext.Close();
                RenderTargetBitmap faceWithRectBitmap = new RenderTargetBitmap(
                    (int)(bitmapSource.PixelWidth * resizeFactor),
                    (int)(bitmapSource.PixelHeight * resizeFactor),
                    96,
                    96,
                    PixelFormats.Pbgra32);

                faceWithRectBitmap.Render(visual);
                FacePhoto1.Source = faceWithRectBitmap;
            }
        }

        private async void BrowseButton2_Click(object sender, RoutedEventArgs e)
        {
            var openDlg = new Microsoft.Win32.OpenFileDialog();

            openDlg.Filter = "JPEG Image(*.jpg)|*.jpg";
            bool? result = openDlg.ShowDialog(this);

            if (!(bool)result)
            {
                return;
            }

            string filePath = openDlg.FileName;

            Uri fileUri = new Uri(filePath);
            BitmapImage bitmapSource = new BitmapImage();

            bitmapSource.BeginInit();
            bitmapSource.CacheOption = BitmapCacheOption.None;
            bitmapSource.UriSource = fileUri;
            bitmapSource.EndInit();

            FacePhoto2.Source = bitmapSource;
            FaceRectangle[] faceRects = new FaceRectangle[0]; ;

            Title = "Detecting...";
            try
            {
                using (Stream imageFileStream = File.OpenRead(filePath))
                {
                    var faces = await faceServiceClient.DetectAsync(imageFileStream);
                    if (faces.Length > 0)
                    {
                        image2 = faces[0].FaceId;
                        var faceRecs = faces.Select(face => face.FaceRectangle);
                        faceRects = faceRecs.ToArray();
                    }

                }
            }
            catch (Exception)
            {
                faceRects = new FaceRectangle[0];
            }
            Title = String.Format("Detection Finished. {0} face(s) detected", faceRects.Length);

            if (faceRects.Length > 0)
            {
                DrawingVisual visual = new DrawingVisual();
                DrawingContext drawingContext = visual.RenderOpen();
                drawingContext.DrawImage(bitmapSource,
                    new Rect(0, 0, bitmapSource.Width, bitmapSource.Height));
                double dpi = bitmapSource.DpiX;
                double resizeFactor = 96 / dpi;

                foreach (var faceRect in faceRects)
                {
                    drawingContext.DrawRectangle(
                        Brushes.Transparent,
                        new Pen(Brushes.Red, 2),
                        new Rect(
                            faceRect.Left * resizeFactor,
                            faceRect.Top * resizeFactor,
                            faceRect.Width * resizeFactor,
                            faceRect.Height * resizeFactor
                            )
                    );
                }

                drawingContext.Close();
                RenderTargetBitmap faceWithRectBitmap = new RenderTargetBitmap(
                    (int)(bitmapSource.PixelWidth * resizeFactor),
                    (int)(bitmapSource.PixelHeight * resizeFactor),
                    96,
                    96,
                    PixelFormats.Pbgra32);

                faceWithRectBitmap.Render(visual);
                FacePhoto2.Source = faceWithRectBitmap;

                var v = await faceServiceClient.VerifyAsync(image1, image2);
                if (v.IsIdentical)
                {
                    Result.Foreground = Brushes.Green;
                    Result.Content = "Verified";
                }
                else
                {
                    Result.Foreground = Brushes.Red;
                    Result.Content = "Not Verified";
                }
            }
        }
    }
}
